package collections;

public class CustomNode {
	int data;
	CustomNode next;
}
